<?php 
///// Debe mostrar la informacion del proyecto y los docentes asociados
$id_proyecto = $_POST['id_proyecto']; // <--- este es el id del proyecto que se manda cuando se selecciona en el modal.

echo "id_proyecto: ".$id_proyecto;
 ?>